package com.nettport.stramdiet.stramdiet;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by bruker on 17.06.2017.
 */

public class SignUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
    }
}
